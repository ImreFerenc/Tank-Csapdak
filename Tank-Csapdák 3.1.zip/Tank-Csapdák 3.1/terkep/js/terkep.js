document.addEventListener("DOMContentLoaded", function () {
    let terkepDoboz = document.getElementById("miskolc-benzinar-terkep");

    if (!terkepDoboz) {
        const leiras = document.querySelector("h4");
        terkepDoboz = document.createElement("div");
        terkepDoboz.id = "miskolc-benzinar-terkep";

        if (leiras) {
            leiras.insertAdjacentElement("afterend", terkepDoboz);
        } else {
            document.body.appendChild(terkepDoboz);
        }
    }

    const szuroSor = document.createElement("div");
    szuroSor.style.cssText = szuroSor.style.cssText = `
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 8px;
    width: 50%;
    margin: 20px auto 10px auto;
`;
    terkepDoboz.insertAdjacentElement("beforebegin", szuroSor);


    // terkepDoboz.style.cssText = "width: 50%; height: 550px; margin-bottom: 25px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1;";


    const map = L.map("miskolc-benzinar-terkep").setView([48.1035, 20.7850], 12);

    const apiKey = "pvYXdPnFtKX6HV6wnJWz";

    L.tileLayer(
    `https://api.maptiler.com/maps/streets-v4/{z}/{x}/{y}.png?key=${apiKey}`,
    {
        tileSize: 512,
        zoomOffset: -1,
        minZoom: 1,
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.maptiler.com/copyright/">MapTiler</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
    }
).addTo(map);


    const benzinkutak = [
     
        { marka: "MOL", nev: "MOL Miskolc - Búza tér", cim: "3526 Miskolc, Búza tér", lat: 48.1057, lng: 20.7908, benzin95: "580 Ft", dizel: "691 Ft", nyitvatartas: "0-24" },
        { marka: "MOL", nev: "MOL Miskolc - Boldva utca", cim: "3526 Miskolc, Boldva u. 2.", lat: 48.1065, lng: 20.8304, benzin95: "580 Ft", dizel: "691 Ft", nyitvatartas: "06:00 - 22:00" },
        { marka: "MOL", nev: "MOL Miskolc - Újgyőri főtér", cim: "3533 Miskolc, Újgyőri főtér 3.", lat: 48.0988, lng: 20.7335, benzin95: "582 Ft", dizel: "693 Ft", nyitvatartas: "06:00 - 20:00" },
        { marka: "MOL", nev: "MOL Miskolc - Pesti út I. (bemenő)", cim: "3508 Miskolc, Pesti út (Görömböly)", lat: 48.0672, lng: 20.7865, benzin95: "585 Ft", dizel: "695 Ft", nyitvatartas: "0-24" },
        { marka: "MOL", nev: "MOL Miskolc - Pesti út II. (kijövő)", cim: "3508 Miskolc, Pesti út (Görömböly)", lat: 48.0665, lng: 20.7852, benzin95: "585 Ft", dizel: "695 Ft", nyitvatartas: "0-24" },

    
        { marka: "OMV", nev: "OMV Miskolc - Búza tér", cim: "3526 Miskolc, Búza tér 16.", lat: 48.1045, lng: 20.7918, benzin95: "593 Ft", dizel: "705 Ft", nyitvatartas: "0-24" },
        { marka: "OMV", nev: "OMV Miskolc - Soltész Nagy Kálmán u.", cim: "3529 Miskolc, Soltész Nagy Kálmán u. 175.", lat: 48.0942, lng: 20.7891, benzin95: "597 Ft", dizel: "708 Ft", nyitvatartas: "06:00 - 22:00" },
        { marka: "OMV", nev: "OMV Miskolc - Testvérvárosok útja (Avas)", cim: "3529 Miskolc, Testvérvárosok útja 2/A", lat: 48.0811, lng: 20.7775, benzin95: "595 Ft", dizel: "706 Ft", nyitvatartas: "0-24" },
        { marka: "OMV", nev: "OMV Miskolc - Kiss tábornok út (Diósgyőr)", cim: "3534 Miskolc, Kiss tábornok u. - Kandó K. u.", lat: 48.1008, lng: 20.7135, benzin95: "593 Ft", dizel: "705 Ft", nyitvatartas: "06:00 - 22:00" },

    
        { marka: "Shell", nev: "Shell Miskolc - Szentpéteri kapu", cim: "3526 Miskolc, Szentpéteri kapu 70.", lat: 48.1182, lng: 20.7852, benzin95: "592 Ft", dizel: "704 Ft", nyitvatartas: "0-24" },
        { marka: "Shell", nev: "Shell Miskolc - Vologda utca", cim: "3527 Miskolc, Vologda utca", lat: 48.1058, lng: 20.7758, benzin95: "592 Ft", dizel: "704 Ft", nyitvatartas: "0-24" },
        { marka: "Shell", nev: "Shell Miskolc - Felsőzsolcai körforgalom", cim: "3527 Miskolc, 3-as főút (Felsőzsolcai körforgó)", lat: 48.1068, lng: 20.8405, benzin95: "594 Ft", dizel: "706 Ft", nyitvatartas: "0-24" },

    
        { marka: "Auchan", nev: "Auchan Miskolc 1 (Borsod / Észak)", cim: "3527 Miskolc, Sajószög utca 1. / József Attila u. 87.", lat: 48.1032, lng: 20.8318, benzin95: "569 Ft", dizel: "685 Ft", nyitvatartas: "0-24 (automata)" },
        { marka: "Auchan", nev: "Auchan Miskolc 2 (Pesti út / Dél)", cim: "3516 Miskolc, Pesti út 9.", lat: 48.0615, lng: 20.7815, benzin95: "569 Ft", dizel: "685 Ft", nyitvatartas: "0-24 (automata)" },

    
        { marka: "Orlen", nev: "ORLEN Miskolc - Szentpéteri kapu", cim: "3526 Miskolc, Szentpéteri kapu 78.", lat: 48.1205, lng: 20.7845, benzin95: "585 Ft", dizel: "696 Ft", nyitvatartas: "05:00 - 21:00" },

    
        { marka: "M.Petrol", nev: "M.Petrol Miskolc - József Attila utca", cim: "3527 Miskolc, József Attila utca 48.", lat: 48.1056, lng: 20.8075, benzin95: "578 Ft", dizel: "690 Ft", nyitvatartas: "0-24" },

    
        { marka: "Egyéb", nev: "AVIA Miskolc - Besenyői utca", cim: "3527 Miskolc, Besenyői utca 24.", lat: 48.1112, lng: 20.7995, benzin95: "579 Ft", dizel: "691 Ft", nyitvatartas: "06:00 - 22:00" },
        { marka: "Egyéb", nev: "ENVI Miskolc - Mésztelep utca", cim: "3527 Miskolc, Mésztelep utca (Metro mellett)", lat: 48.1048, lng: 20.8245, benzin95: "575 Ft", dizel: "688 Ft", nyitvatartas: "0-24 (automata)" },
        { marka: "Egyéb", nev: "Olajpark Benzinkút - Kiss Ernő u.", cim: "3531 Miskolc, Kiss Ernő utca 7.", lat: 48.1013, lng: 20.7601, benzin95: "577 Ft", dizel: "689 Ft", nyitvatartas: "0-24" },
        { marka: "Egyéb", nev: "HunPetrol - Kiss Ernő u.", cim: "3532 Miskolc, Kiss Ernő utca 35.", lat: 48.1018, lng: 20.7485, benzin95: "578 Ft", dizel: "690 Ft", nyitvatartas: "06:00 - 22:00" },
        { marka: "Egyéb", nev: "Palviscsák-Trans Benzinkút", cim: "3527 Miskolc, Sajószigeti út", lat: 48.1095, lng: 20.8125, benzin95: "583 Ft", dizel: "694 Ft", nyitvatartas: "06:00 - 20:00" }
    ];


    const markerLayer = L.layerGroup().addTo(map);

    // Kiválasztott benzinkutak
    let kivalasztottKutak = [];

    // Összehasonlító táblázat létrehozása
    const osszehasonlitoDoboz = document.createElement("div");

    osszehasonlitoDoboz.style.cssText = `
        width: 50%;
        margin: 30px auto;
        overflow-x: auto;
`;

    terkepDoboz.insertAdjacentElement("afterend", osszehasonlitoDoboz);

    function kutKivalasztasa(kut) {

    // Ha már ki van választva, eltávolítjuk
    const index = kivalasztottKutak.findIndex(
        elem => elem.nev === kut.nev
    );

    if (index !== -1) {
        kivalasztottKutak.splice(index, 1);
    } 
    else {

        // Maximum két benzinkút választható
        if (kivalasztottKutak.length >= 2) {
            alert("Maximum két benzinkutat választhatsz ki!");
            return;
        }

        kivalasztottKutak.push(kut);
    }

    tablaMegjelenitese();
}

function tablaMegjelenitese() {

    if (kivalasztottKutak.length === 0) {
        osszehasonlitoDoboz.innerHTML = "";
        return;
    }

    if (kivalasztottKutak.length === 1) {
        osszehasonlitoDoboz.innerHTML = `
            <h3 style="text-align:center;">
                Válassz még egy benzinkutat az összehasonlításhoz!
            </h3>
        `;
        return;
    }

    const kut1 = kivalasztottKutak[0];
    const kut2 = kivalasztottKutak[1];

    osszehasonlitoDoboz.innerHTML = `
        <h2 style="text-align:center;">
            Benzinkutak összehasonlítása
        </h2>

        <table style="
            width:100%;
            border-collapse:collapse;
            text-align:center;
            font-family:Arial;
            background:#eee;
        ">

            <thead>
                <tr style="background:#000;color:white;">
                    <th>Jellemzők</th>
                    <th>1. Benzinkút: ${kut1.marka}</th>
                    <th>2. Benzinkút: ${kut2.marka}</th>
                </tr>
            </thead>

            <tbody>

                <tr>
                    <th>Benzinkút neve</th>
                    <td>${kut1.nev}</td>
                    <td>${kut2.nev}</td>
                </tr>

                <tr>
                    <th>Cím</th>
                    <td>${kut1.cim}</td>
                    <td>${kut2.cim}</td>
                </tr>

                <tr>
                    <th>95-ös benzin ára</th>
                    <td>${kut1.benzin95} / liter</td>
                    <td>${kut2.benzin95} / liter</td>
                </tr>

                <tr>
                    <th>Dízel ára</th>
                    <td>${kut1.dizel} / liter</td>
                    <td>${kut2.dizel} / liter</td>
                </tr>

                <tr>
                    <th>Nyitvatartás</th>
                    <td>${kut1.nyitvatartas}</td>
                    <td>${kut2.nyitvatartas}</td>
                </tr>

            </tbody>
        </table>

        <div style="text-align:center;margin-top:15px;">
            <button id="torlesGomb"
    style="
        padding:10px 20px;
        background:#d32f2f;
        color:white;
        border:none;
        border-radius:6px;
        cursor:pointer;
    ">
    Kiválasztás törlése
</button>
        </div>
    `;

    const torlesGomb = document.getElementById("torlesGomb");

torlesGomb.addEventListener("click", osszehasonlitasTorlese);
}

function osszehasonlitasTorlese() {
    kivalasztottKutak = [];
    tablaMegjelenitese();
}



    function megjelenitKutakat(szurtMarka) {
        markerLayer.clearLayers();

        benzinkutak.forEach(function (kut) {
            if (szurtMarka === "Összes" || kut.marka === szurtMarka) {
                const popupHtml = `
                    <div style="font-family: Arial, sans-serif; min-width: 190px; line-height: 1.5;">
                        <span style="background: #222; color: #fff; padding: 2px 6px; border-radius: 4px; font-size: 11px;">${kut.marka}</span>
                        <h4 style="margin: 6px 0 2px 0; font-size: 14px;">${kut.nev}</h4>
                        <div style="font-size: 12px; color: #555; margin-bottom: 6px;">📍 ${kut.cim}</div>
                        <div style="background: #f4f6f8; padding: 6px 8px; border-radius: 6px; font-size: 13px;">
                            ⛽ <b>95-ös benzin:</b> ${kut.benzin95}<br>
                            🚛 <b>Dízel:</b> ${kut.dizel}
                        </div>
                        <div style="font-size: 11px; color: #666; margin-top: 6px;">🕒 Nyitvatartás: ${kut.nyitvatartas}</div>
                    </div>
                `;

                const marker = L.marker([kut.lat, kut.lng])
    .bindPopup(popupHtml)
    .addTo(markerLayer);

marker.on("click", function () {
    kutKivalasztasa(kut);
});
            }
        });
    }


    const markak = ["Összes", "MOL", "OMV", "Shell", "Auchan", "Orlen", "M.Petrol", "Egyéb"];

    markak.forEach(function (marka) {
        const gomb = document.createElement("button");
        gomb.textContent = marka;
        gomb.style.cssText = "padding: 6px 14px; border: 1px solid #ccc; border-radius: 20px; background: #fff; cursor: pointer; font-weight: bold; font-size: 13px;";

        if (marka === "Összes") {
            gomb.style.background = "#1a73e8";
            gomb.style.color = "#fff";
            gomb.style.borderColor = "#1a73e8";
        }

        gomb.addEventListener("click", function () {
        
            Array.from(szuroSor.children).forEach(btn => {
                btn.style.background = "#fff";
                btn.style.color = "#000";
                btn.style.borderColor = "#ccc";
            });
            // Aktív gomb kiemelése
            gomb.style.background = "#1a73e8";
            gomb.style.color = "#fff";
            gomb.style.borderColor = "#1a73e8";

            megjelenitKutakat(marka);
        });

        szuroSor.appendChild(gomb);
    });


    megjelenitKutakat("Összes");

    function tablaMeretezes() {
    osszehasonlitoDoboz.style.width =
        window.innerWidth <= 768 ? "95%" : "50%";
}

window.addEventListener("resize", tablaMeretezes);

tablaMeretezes();
});